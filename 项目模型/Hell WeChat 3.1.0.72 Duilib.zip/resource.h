//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� GetUserInfoByWxid.rc ʹ��
//
#define IDP_CLOSE                       102
#define IDP_CLOSE_HOT                   103
#define IDP_WECHAT_LOGO_WHITE           104
#define IDP_MIN                         105
#define IDP_MIN_HOT                     106
#define IDX_MAIN                        107
#define IDX_FOOTER                      109
#define IDX_HEADER                      110
#define IDI_ICON1                       111
#define IDI_LOGO                        111

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
